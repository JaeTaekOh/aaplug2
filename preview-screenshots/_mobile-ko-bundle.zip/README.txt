AA Plug 2 — SnapLedger (com.sample.snapledger)
2026-11-12

이 폴더에는 AA Plug 2가 만든 스토어 문구, 정책 문서, 양식 답안, 그래픽, 코드 수정안이 들어 있어요. 제출은 직접 하며, AA Plug 2는 자동으로 제출하지 않아요.
